CREATE VIEW v_app_test AS
  SELECT
    `test_2206`.`app_book_book`.`id`       AS `id`,
    `test_2206`.`app_book_book`.`title`    AS `title`,
    `test_2206`.`app_book_book`.`press_id` AS `press_id`
  FROM `test_2206`.`app_book_book`
  WHERE (`test_2206`.`app_book_book`.`press_id` = (SELECT `test_2206`.`app_book_press`.`id`
                                                   FROM `test_2206`.`app_book_press`
                                                   WHERE (`test_2206`.`app_book_press`.`name` = '五道口出版社')));

